from app import db

class Producto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre_del_producto = db.Column(db.String(255), nullable=False)
    descripcion_del_producto = db.Column(db.Text)
