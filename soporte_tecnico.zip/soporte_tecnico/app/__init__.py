from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Crear la instancia de la aplicación
app = Flask(__name__)

# Configuración de la base de datos
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://username:password@localhost/solu'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar SQLAlchemy con la instancia de Flask
db = SQLAlchemy(app)

# Asegúrate de importar los modelos y las vistas después de crear la instancia de db
from .models import *
from .views import *
