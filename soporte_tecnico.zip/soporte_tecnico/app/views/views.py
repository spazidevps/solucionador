from flask import render_template, request, redirect, url_for, flash
from app import app, db
from app.models import Producto

@app.route('/')
def home():
    # Esta es la página de inicio que podría mostrar información básica o enlaces.
    return render_template('inicio.html')

@app.route('/crear_producto', methods=['GET', 'POST'])
def crear_producto():
    if request.method == 'POST':
        # Obtener datos del formulario
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        
        # Crear una nueva instancia de Producto
        nuevo_producto = Producto(nombre_del_producto=nombre, descripcion_del_producto=descripcion)
        
        # Añadir la instancia a la base de datos y guardar los cambios
        db.session.add(nuevo_producto)
        db.session.commit()
        
        # Mostrar un mensaje de éxito y redireccionar a la misma página para limpiar el formulario
        flash('Producto creado con éxito!')
        return redirect(url_for('crear_producto'))
    
    # Si no es una petición POST, simplemente renderizar el formulario
    return render_template('crear_producto.html')
