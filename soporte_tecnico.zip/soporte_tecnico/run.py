from app import app  # Esto importa la instancia 'app' de Flask creada en __init__.py

if __name__ == '__main__':
    app.run(debug=True)
